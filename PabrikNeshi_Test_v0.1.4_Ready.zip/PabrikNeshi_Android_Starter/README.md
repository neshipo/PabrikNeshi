# Pabrik Neshi — Android Starter 0.1.1

Aplikasi Android native berbasis Kotlin untuk pendamping game Aniimo. Versi ini berisi:

- Home screen dark navy dengan aksen ungu dan cyan.
- Navigasi Home, Map, dan Info.
- Aniidex Interactive Map dibuka di dalam Android WebView: https://aniidex.com/id/map/
- JavaScript, DOM Storage, dan database web aktif untuk kebutuhan situs interaktif.
- Zoom WebView aktif dengan kontrol zoom bawaan disembunyikan.
- Tombol Muat Ulang dan Browser pada halaman Map.
- Navigasi top-level dibatasi ke HTTPS `aniidex.com` dan subdomainnya. Link web eksternal dibuka di browser HP.
- File/content access dimatikan, mixed content diblokir, Safe Browsing aktif jika tersedia, dan error sertifikat SSL dibatalkan.
- GitHub Actions workflow untuk membuat APK debug secara online, sehingga build dapat dilakukan tanpa laptop.

## Build APK hanya dengan HP Android

### Yang diperlukan
- HP Android dan browser (Chrome disarankan).
- Akun GitHub gratis.
- File ZIP project ini.

### Langkah
1. Unduh dan ekstrak ZIP project di HP. Jika pengelola file HP tidak bisa mengekstrak, gunakan aplikasi pengarsip ZIP.
2. Buka https://github.com/ lalu masuk atau buat akun.
3. Buat repository baru bernama `PabrikNeshi`. Pilih **Public** agar pengaturan awal Actions lebih sederhana. Jangan unggah password, token, atau data pribadi.
4. Di repository, pilih **Add file → Upload files**. Unggah isi folder `PabrikNeshi_Android_Starter` (termasuk folder `.github`). Pastikan `.github/workflows/build-apk.yml` ikut terunggah. Commit perubahan.
5. Buka tab **Actions** pada repository. Pilih workflow **Build Pabrik Neshi APK**, lalu tekan **Run workflow** jika belum berjalan otomatis.
6. Tunggu sampai workflow selesai dengan tanda centang hijau.
7. Buka hasil run tersebut, gulir ke **Artifacts**, lalu unduh `Pabrik-Neshi-debug-APK`.
8. Ekstrak file artifact ZIP, lalu ketuk `app-debug.apk` untuk memasangnya. Jika Android meminta izin, izinkan instalasi dari sumber tersebut hanya untuk aplikasi/file manager yang kamu gunakan.

Jika repository dibuat Private, GitHub Actions tetap dapat digunakan pada batas penggunaan paket akun yang berlaku. Tidak perlu mengubah repository menjadi Public jika kamu sudah memahami pengaturan Actions.

## Build dengan Android Studio (opsional)
- JDK 17
- Gradle 8.11.1
- Android Gradle Plugin 8.9.1
- Android SDK Platform 35

Jalankan `gradle :app:assembleDebug`. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Pengujian penting

Belum ada klaim bahwa situs Aniidex pasti mendukung WebView. Setelah APK terpasang, uji hal berikut:
- halaman map dapat dimuat melalui koneksi internet;
- peta dapat digeser dan di-zoom;
- marker, pencarian, dan filter bekerja;
- cookie atau login (jika tersedia) berfungsi;
- tautan eksternal dibuka di browser;
- tombol kembali Android bekerja.

Jika situs menolak WebView, meminta browser tertentu, atau memiliki batasan embed, gunakan tombol Browser atau minta izin/dukungan dari pengelola situs. Jangan mengakali pembatasan akses situs.

## Catatan

Ini adalah aplikasi pendamping/fan-made tidak resmi dan tidak berafiliasi dengan Aniimo maupun Aniidex. Peta, marker, dan data lokasi tetap dimiliki serta disediakan oleh Aniidex. APK yang dihasilkan workflow adalah **debug APK**, bukan rilis Play Store bertanda tangan produksi.
