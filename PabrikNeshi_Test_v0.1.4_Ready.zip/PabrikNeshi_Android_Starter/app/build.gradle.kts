plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.neshi.pabrikneshi"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.neshi.pabrikneshi.test"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.4"
    }
}
