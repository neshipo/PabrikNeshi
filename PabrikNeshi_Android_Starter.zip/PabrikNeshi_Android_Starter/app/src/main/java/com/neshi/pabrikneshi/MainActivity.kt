package com.neshi.pabrikneshi

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.SafeBrowsingResponse
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.graphics.Bitmap
import android.net.http.SslError

class MainActivity : Activity() {
    private val mapUrl = "https://aniidex.com/id/map/"
    private val bg = Color.rgb(8, 11, 22)
    private val panel = Color.rgb(18, 23, 40)
    private val purple = Color.rgb(155, 123, 255)
    private val cyan = Color.rgb(73, 213, 232)
    private val white = Color.WHITE
    private val muted = Color.rgb(165, 174, 195)

    private lateinit var root: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var homeView: View
    private var mapLoaded = false
    private var showingMap = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildLayout()
        showHome()
    }

    private fun buildLayout() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(14))
            setBackgroundColor(bg)
        }
        header.addView(label("PABRIK NESHI", 20f, white, true))
        header.addView(label("ANIIMO COMPANION  •  INTERACTIVE MAP", 10f, muted, true).apply {
            letterSpacing = 0.08f
            setPadding(0, dp(4), 0, 0)
        })
        root.addView(header)

        content = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        root.addView(content)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(9), dp(10), dp(10))
            setBackgroundColor(Color.rgb(12, 16, 30))
        }
        nav.addView(navButton("⌂\nHOME") { showHome() }, weightParams())
        nav.addView(navButton("◎\nMAP") { showMap() }, weightParams())
        nav.addView(navButton("☆\nINFO") { showInfo() }, weightParams())
        root.addView(nav)
        setContentView(root)

        webView = WebView(this).apply {
            setBackgroundColor(bg)
            settings.javaScriptEnabled = true // Dibutuhkan oleh peta interaktif.
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.setSupportZoom(true)
            settings.builtInZoomControls(true)
            settings.displayZoomControls(false)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                settings.safeBrowsingEnabled = true
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    if (::progress.isInitialized) {
                        progress.progress = newProgress
                        progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    return handleNavigation(request.url)
                }

                @Suppress("DEPRECATION")
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                    return handleNavigation(Uri.parse(url))
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    if (::progress.isInitialized) progress.visibility = View.VISIBLE
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (::progress.isInitialized) progress.visibility = View.GONE
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: android.webkit.WebResourceError?
                ) {
                    super.onReceivedError(view, request, error)
                    if (request?.isForMainFrame == true) {
                        Toast.makeText(
                            this@MainActivity,
                            "Map gagal dimuat. Periksa internet lalu tekan Muat Ulang.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                    handler?.cancel() // Jangan abaikan sertifikat HTTPS yang bermasalah.
                }
            }
        }

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = false
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(cyan)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(panel)
            visibility = View.GONE
        }
    }

    private fun showHome() {
        showingMap = false
        content.removeAllViews()
        if (::webView.isInitialized) webView.visibility = View.GONE
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
        }
        page.addView(label("Selamat datang di", 14f, muted, false))
        page.addView(label("Pabrik Neshi", 30f, white, true).apply {
            setPadding(0, dp(3), 0, dp(6))
        })
        page.addView(label("Teman eksplorasi duniamu di Aniimo.", 14f, muted, false))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(18))
            background = rounded(panel, 20)
        }
        val cardParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(28) }
        card.addView(label("ANIIMO  /  INTERACTIVE MAP", 11f, cyan, true))
        card.addView(label("Jelajahi setiap sudut Idyll", 21f, white, true).apply {
            setPadding(0, dp(10), 0, dp(6))
        })
        card.addView(label("Buka peta komunitas Aniidex langsung dari dalam aplikasi.", 13f, muted, false))
        val open = actionButton("BUKA INTERACTIVE MAP") { showMap() }
        val openParams = LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(18) }
        card.addView(open, openParams)
        page.addView(card, cardParams)

        page.addView(label("FITUR", 11f, purple, true).apply { setPadding(0, dp(28), 0, dp(12)) })
        page.addView(featureRow("◎", "Interactive Map", "Peta Aniimo dari Aniidex"))
        page.addView(featureRow("☆", "Favorites", "Disiapkan untuk pengembangan berikutnya"))
        page.addView(featureRow("⌕", "Game tools", "Ruang untuk fitur Aniimo selanjutnya"))
        content.addView(page)
    }

    private fun showMap() {
        showingMap = true
        content.removeAllViews()

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(7), dp(12), dp(7))
            setBackgroundColor(panel)
        }
        toolbar.addView(label("ANIIMO MAP", 11f, cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
        toolbar.addView(smallAction("Muat Ulang") {
            mapLoaded = true
            webView.reload()
        })
        toolbar.addView(smallAction("Browser") {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(mapUrl)))
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "Browser tidak ditemukan", Toast.LENGTH_SHORT).show()
            }
        }.apply { setPadding(dp(8), 0, 0, 0) })
        page.addView(toolbar, LinearLayout.LayoutParams(-1, dp(48)))

        val wrapper = FrameLayout(this)
        webView.visibility = View.VISIBLE
        wrapper.addView(webView, FrameLayout.LayoutParams(-1, -1))
        wrapper.addView(progress, FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP))
        page.addView(wrapper, LinearLayout.LayoutParams(-1, 0, 1f))
        content.addView(page)

        if (!mapLoaded) {
            mapLoaded = true
            webView.loadUrl(mapUrl)
        }
    }

    private fun smallAction(text: String, click: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(white)
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(8), dp(8), dp(8))
        setOnClickListener { click() }
    }

    private fun showInfo() {
        showingMap = false
        content.removeAllViews()
        webView.visibility = View.GONE
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
        }
        page.addView(label("Tentang Pabrik Neshi", 24f, white, true))
        page.addView(label("Versi 0.1.0 • Aniimo Companion", 13f, cyan, true).apply {
            setPadding(0, dp(8), 0, dp(18))
        })
        page.addView(label("Peta ditampilkan dari website Aniidex. Konten peta, marker, kategori, dan data lokasi dikelola oleh penyedia website tersebut.", 14f, muted, false))
        page.addView(label("Website sumber", 12f, purple, true).apply { setPadding(0, dp(24), 0, dp(6)) })
        page.addView(label(mapUrl, 13f, white, false))
        page.addView(label("Catatan: aplikasi ini adalah proyek pendamping tidak resmi dan tidak berafiliasi dengan pengembang Aniimo maupun Aniidex.", 12f, muted, false).apply {
            setPadding(0, dp(24), 0, 0)
        })
        content.addView(page)
    }

    private fun handleNavigation(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase()
        val host = uri.host?.lowercase().orEmpty()
        val trusted = host == "aniidex.com" || host.endsWith(".aniidex.com")
        if (scheme == "https" && trusted) return false
        if (scheme == "http" || scheme == "https") {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "Tidak ada browser untuk membuka tautan ini", Toast.LENGTH_SHORT).show()
            }
        }
        return true
    }

    override fun onBackPressed() {
        if (showingMap && webView.canGoBack()) {
            webView.goBack()
        } else if (showingMap) {
            showHome()
        } else {
            super.onBackPressed()
        }
    }

    private fun featureRow(icon: String, title: String, subtitle: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(panel, 14)
        }
        val glyph = label(icon, 23f, purple, true).apply { gravity = Gravity.CENTER }
        row.addView(glyph, LinearLayout.LayoutParams(dp(38), dp(42)))
        val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textCol.addView(label(title, 14f, white, true))
        textCol.addView(label(subtitle, 11f, muted, false).apply { setPadding(0, dp(3), 0, 0) })
        row.addView(textCol, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
        return row.also {
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(9)
            it.layoutParams = lp
        }
    }

    private fun navButton(text: String, click: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 10f
        isAllCaps = false
        setTextColor(white)
        background = rounded(Color.TRANSPARENT, 10)
        setOnClickListener { click() }
        minHeight = dp(48)
        minimumHeight = dp(48)
        stateListAnimator = null
    }

    private fun actionButton(text: String, click: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        isAllCaps = false
        setTextColor(Color.rgb(9, 12, 24))
        background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(purple, cyan)
        ).apply { cornerRadius = dp(14).toFloat() }
        setOnClickListener { click() }
        stateListAnimator = null
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        includeFontPadding = true
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, -2, 1f)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (::webView.isInitialized) {
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.removeAllViews()
            webView.destroy()
        }
        super.onDestroy()
    }
}
